package encrpt;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.BufferedReader;
import java.io.File;
import java.io.PrintWriter;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class frame1 extends javax.swing.JFrame {

    private BufferedImage originalImage;
    private BufferedImage resultImage;
    private int[][] currentKey;
    private double currentEncrypttime;
    private double currentDycrepttime; 
    private double currentNPCR;
    private double currentUACI;
    private int max = 255;

    public frame1() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 292, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 304, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(292, 365));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 292, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jLabel1.setText("original");

        jButton1.setText("encrypt");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("decrypt");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel2.setText("result");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(69, 69, 69)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton1)
                            .addComponent(jButton2)))
                    .addComponent(jLabel1))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(335, 335, 335))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(127, 127, 127)
                                .addComponent(jButton1)
                                .addGap(93, 93, 93)
                                .addComponent(jButton2))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(115, 115, 115))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        originalImage = loadImage();
        originalImage = toGrayScale(originalImage);
        repaint();
        resultImage = encryptImage(originalImage);
        repaint();
        saveKey(currentKey);
        saveImage(resultImage);
        saveData();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        originalImage = loadImage();
        repaint();
        resultImage = null;
        jPanel2.getGraphics().clearRect(0, 0, jPanel2.getWidth(), jPanel2.getHeight());
        currentKey = loadkey();
        resultImage = decryptImage(originalImage, currentKey);
        repaint();
        //saveImage(resultImage);
    }//GEN-LAST:event_jButton2ActionPerformed

    int[][] loadkey() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File("C:"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Txt Files", "txt");
        fileChooser.setFileFilter(filter);
        fileChooser.showDialog(this, "Select key");
        File file = fileChooser.getSelectedFile();
        try {

            int Width;
            int Height;
            Scanner in = new Scanner(file);
            Width = in.nextInt();
            Height = in.nextInt();
            int[][] keyMatrix = new int[Width][Height];
            for (int i = 0; i < Width; i++) {
                for (int j = 0; j < Height; j++) {
                    keyMatrix[i][j] = in.nextInt();
                }
            }
            return keyMatrix;

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, e.getMessage() + "\n" + e.toString(), "Fatal Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private BufferedImage loadImage() {   //buffered image
        JFileChooser jcr = new JFileChooser();
        jcr.setCurrentDirectory(new File("C:"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG Images", "png");
        jcr.setFileFilter(filter);
        jcr.showDialog(this, "select an image");
        File file = jcr.getSelectedFile();
        BufferedImage img = null;
        try {
            img = ImageIO.read(file);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, e.getMessage() + "\n" + e.toString(), "Fatal Error", JOptionPane.ERROR_MESSAGE);
        }
        return img;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frame1().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
 private BufferedImage toGrayScale(BufferedImage originalImage) {
        int[][] pixels = convertImageToMatrix(originalImage);
        BufferedImage result = convertMatrixToImage(pixels);
        return result;
    }

    private int[][] convertImageToMatrix(BufferedImage img) {
        try {
            Raster raster = img.getData();
            int w = img.getWidth();
            int h = img.getHeight();
            int[][] pixels = new int[w][h];
            for (int x = 0; x < w; x++) {
                for (int y = 0; y < h; y++) {
                    pixels[x][y] = raster.getSample(x, y, 0);
                }
            }
            return pixels;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage() + "\n"
                    + ex.toString(), "FetalError", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    private BufferedImage convertMatrixToImage(int[][] pixels) {
        int w = pixels.length;
        int h = pixels[0].length;
        BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
        WritableRaster raster = (WritableRaster) image.getData();
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                raster.setSample(x, y, 0, pixels[x][y]);
            }
        }
        image.setData(raster);
        return image;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (originalImage != null) {
            int minWidth = Math.min(originalImage.getWidth(),
                    jPanel1.getWidth());
            int minHeight = Math.min(originalImage.getWidth(),
                    jPanel1.getWidth());
            jPanel1.getGraphics().drawImage(originalImage,
                    0, 0, minWidth, minHeight, jPanel1);
        }
        if (resultImage != null) {
           
            int minWidth = Math.min(resultImage.getWidth(),
                    jPanel2.getWidth());
            int minHeight = Math.min(resultImage.getWidth(),
                    jPanel2.getWidth());
            jPanel2.getGraphics().drawImage(resultImage,
                    0, 0, minWidth, minHeight, jPanel2);
        }
    }

    private BufferedImage encryptImage(BufferedImage image) {
        int[][] mat1 = convertImageToMatrix(image);
        long starttime = Calendar.getInstance().getTimeInMillis();
        int row = mat1.length;
        int cols = mat1[0].length;
        currentKey = generaterandomkey(row, cols);
        int[][] mat2 = applyXOR(mat1, currentKey);
        BufferedImage result = convertMatrixToImage(mat2);
        long Endtime = Calendar.getInstance().getTimeInMillis();
        currentEncrypttime = (starttime - Endtime) / 1000;
        currentNPCR = calculateNPCR(mat1, mat2);
        currentUACI = calculateUACI(mat1, mat2);
        String output = "Image Size = " + result.getWidth() + "*" + result.getHeight() + "/n";
        output += "NPCR =" + String.format("%.2f", currentNPCR) + "%" + "\n";
        output += "UACI =" + String.format("%.2f", currentUACI) + "%" + "\n";
        output += "Encrypttion time (in sceconds) =" + currentEncrypttime + "/n";
        JOptionPane.showMessageDialog(this, output, "report", JOptionPane.INFORMATION_MESSAGE);

        return result;
    }
     private BufferedImage decryptImage(BufferedImage image,int[][] key) {
        long startTime = Calendar.getInstance().getTimeInMillis();
        int[][] beforeDecrypt = convertImageToMatrix(image);
        int[][] afterDecrypt = applyXOR(beforeDecrypt, key);
        BufferedImage result = convertMatrixToImage(afterDecrypt);
        long Endtime = Calendar.getInstance().getTimeInMillis();
        currentDycrepttime = (Endtime - startTime) /1000 ; 
        JOptionPane.showMessageDialog(this, "Decryption time ="+ String.valueOf(currentDycrepttime), "report", JOptionPane.INFORMATION_MESSAGE);
        return result;
     }
    private int[][] generaterandomkey(int r, int c) {
        int[][] key = new int[r][c];
        Random robj = new Random();
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                int v = robj.nextInt(max + 1);
                key[i][j] = v;
            }
        }
        return key;

    }

    private int[][] applyXOR(int[][] x, int[][] y) {
        int noofrows = x.length;
        int noofcols = x[0].length;
        int[][] z = new int[noofrows][noofcols];
        for (int i = 0; i < noofrows; i++) {
            for (int j = 0; j < noofcols; j++) {
                z[i][j] = x[i][j] ^ y[i][j];
            }
        }
        return z;
    }

    private double calculateNPCR(int[][] mat1, int[][] mat2) {
        int s = 0;
        int noofrows = mat1.length;
        int noofcols = mat1[0].length;
        for (int i = 0; i < noofrows; i++) {
            for (int j = 0; j < noofcols; j++) {
                if (mat1[i][j] != mat2[i][j]) {
                    s++;
                }
            }
        }
        double npcr = (double) s / (noofrows * noofcols) * 100;
        return npcr;
    }

    private double calculateUACI(int[][] mat1, int[][] mat2) {

        int s = 0;
        int noofrows = mat1.length;
        int noofcols = mat1[0].length;
        for (int i = 0; i < noofrows; i++) {
            for (int j = 0; j < noofcols; j++) {
                int diff = Math.abs(mat1[i][j] - mat2[i][j]);
                s += diff;
            }
        }
        double uaci = (double) s / 255 * 100 / (noofrows * noofcols);
        return uaci;
    }

    private void saveKey(int[][] key) {
        JFileChooser jfc = new JFileChooser();
        jfc.setCurrentDirectory(new File("E:\\Image"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
        jfc.setFileFilter(filter);
        jfc.showDialog(this, "save current key");
        String path = jfc.getSelectedFile().getPath() + ".txt";
        File f = new File(path);
        try {
            PrintWriter pw = new PrintWriter(f);
            pw.println(key.length);
            pw.println(key[0].length);
            for (int i = 0; i < key.length; i++) {
                for (int j = 0; j < key[0].length; j++) {
                    pw.println(key[i][j]);
                }
            }
            pw.flush();
            pw.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, e.getMessage() + "\n" + e.toString(), "Fatal Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveData() {
        JFileChooser jfc = new JFileChooser();
        jfc.setCurrentDirectory(new File("E:\\Image"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
        jfc.setFileFilter(filter);
        jfc.showDialog(this, "save Data");
        String path = jfc.getSelectedFile().getPath() + ".txt";
        File f = new File(path);
        try {
            PrintWriter pw = new PrintWriter(f);
            pw.println("image size=" + originalImage.getWidth() + "*" + originalImage.getHeight());
            pw.println("npcr=" + String.format("%.2f", currentNPCR) + "%");
            pw.println("UACI =" + String.format("%.2f", currentUACI) + "%");
            pw.println("Encrypttion time (in sceconds) =" + currentEncrypttime);
            pw.flush();
            pw.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, e.getMessage() + "\n" + e.toString(), "Fatal Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveImage(BufferedImage image) {
        try {
            JFileChooser jfc = new JFileChooser();
            jfc.setCurrentDirectory(new File("E:\\Image"));
            FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG Image", "png");
            jfc.setFileFilter(filter);
            jfc.showDialog(this, "save result image");
            String path = jfc.getSelectedFile().getPath() + ".png";
            File f = new File(path);
            ImageIO.write(image, "png", f);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, e.getMessage() + "\n" + e.toString(), "Fatal Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
