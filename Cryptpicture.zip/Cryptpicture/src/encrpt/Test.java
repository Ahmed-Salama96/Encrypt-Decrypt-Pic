/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encrpt;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Dr Adel Khamis Solim
 */
public class Test {
    
    public static void main(String[] args) throws FileNotFoundException {
        
        File file=new File("test.txt");
        Scanner scan=new Scanner(file);
        
        
        while(scan.hasNextLine())
        {
            
            System.out.println(scan.nextLine());
            
        }
        
        scan.close();
        
    }
    
    
}
